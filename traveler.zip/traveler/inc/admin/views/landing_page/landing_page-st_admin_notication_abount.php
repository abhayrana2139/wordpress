<div class="traveler-important-notice">

        <p class="about-description"><?php echo __("All options removed in ThemeOptions of theme:", 'traveler') ; ?><br>

		<a href="http://guide.travelerwp.com/docs/theme-layout/new-modern-layout/the-options-have-removed-in-the-modern-layout"> http://guide.travelerwp.com/docs/theme-layout/new-modern-layout/the-options-have-removed-in-the-modern-layout</a></p>

		<p class="about-description">

			For the search form at home page in all layouts.<br>

			By update, optimize for travel trending our our theme we had change something in our design and structure for the Modern layout.<br>

			In the Modern layout, there are no options for the customer can change the fields of the search form. <br>

			We have used hard-code for this section for fit with UX/UI of travel site. Of course client can make any custom for change layout by use child-theme for match with requirements.<br>

		</p>

		<p class="about-description">

			For the layout of the search page and detail page of the service<br>

			The customer can not create custom layout like when using classic layout. We have created some fixed layout option so you can only choose one of them.<br>

			<a href="http://guide.travelerwp.com/wp-content/uploads/2019/05/hotel-search-result.png">http://guide.travelerwp.com/wp-content/uploads/2019/05/hotel-search-result.png</a>

		</p>

		<p class="about-description">

		For the filter sidebar in the search result page<br>

		You can still create filter option dynamically in the sidebar of the search result page. You can refer our document for for more details in here: <a href="http://guide.travelerwp.com/docs/theme-layout/new-modern-layout/homap-demo/new-hotel-search-result/" >http://guide.travelerwp.com/docs/theme-layout/new-modern-layout/homap-demo/new-hotel-search-result</a>

		</p>

</div>

