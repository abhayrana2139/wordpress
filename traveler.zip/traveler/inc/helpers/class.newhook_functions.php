<?php
if ( !function_exists( 'st_add_scripts' ) ) {
    function st_add_scripts(){

    }
}