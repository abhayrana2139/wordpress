<?php
/**
 * Created by PhpStorm.
 * User: Dannie
 * Date: 8/20/2018
 * Time: 1:44 PM
 */

class ST_Hotel_Service extends ST_Base_Service
{
    public function __construct($post)
    {
        parent::__construct($post);
    }

}