<?php

/**

 * Created by wpbooking.

 * Developer: nasanji

 * Date: 6/26/2017

 * Version: 1.0

 */



wp_enqueue_script('magnific.js');



?>

<h3 class="booking-title sum-result-filter"><span id="count-filter"></span>

    <small><a class="popup-text" href="#search-flight-dialog" data-effect="mfp-zoom-out"><?php echo esc_html__('Change search', 'traveler'); ?></a></small>

</h3>

