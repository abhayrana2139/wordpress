<div class="alert alert-warning">

    <strong><?php esc_html_e('Warning!', 'traveler'); ?></strong>  <?php esc_html_e('Nothing Found', 'traveler'); ?>

</div>