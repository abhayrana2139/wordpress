<footer id="st-footer-tour-modern" class="st-ite-footer">

</footer>
<?php wp_footer(); ?>
</body>
</html>